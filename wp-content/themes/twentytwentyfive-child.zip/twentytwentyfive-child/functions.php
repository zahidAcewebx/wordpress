<?php

function my_theme_enqueue_styles() {
    $parent_style = 'twentytwentyfive-style'; // This is 'parent-style' for the twentytwentyfive theme.
    wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css' );
    wp_enqueue_style( 'child-style',
        get_stylesheet_directory_uri() . '/style.css',
        array( $parent_style ),
        wp_get_theme()->get('Version')
    );
}
add_action( 'wp_enqueue_scripts', 'my_theme_enqueue_styles' );


function my_theme_register_menus() {
    register_nav_menus(
        array(
            'primary' => __( 'Primary Menu', 'Top Menu' ),
             'footer'  => __( 'Footer Menu', 'Top Menu' ),
        )
    );
}
add_action( 'after_setup_theme', 'my_theme_register_menus' );
