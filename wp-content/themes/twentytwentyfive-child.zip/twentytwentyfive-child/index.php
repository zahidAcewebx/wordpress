<?php 
die();
echo "dddddddd";
 get_header('header');
?> 